import os
import tempfile
import pytest

@pytest.fixture()
def client(monkeypatch):
    folder=tempfile.TemporaryDirectory()
    monkeypatch.setenv('VOLUNTEER_DB',os.path.join(folder.name,'test.sqlite3'))
    import app as module
    module.DATABASE=module.Path(os.environ['VOLUNTEER_DB'])
    module.app.config.update(TESTING=True)
    with module.app.test_client() as c:
        yield c
    folder.cleanup()

def csrf(client):
    with client.session_transaction() as sess:
        token=sess.get('csrf')
        if not token:
            token='test-csrf-token';sess['csrf']=token
        return token

def test_first_setup_and_login(client):
    assert client.get('/').status_code==200
    assert client.get('/register').status_code==200
    assert client.get('/login').status_code==200
    assert client.get('/setup').status_code==200
    token=csrf(client)
    response=client.post('/setup',data={'csrf_token':token,'name':'Admin','email':'admin@demo.kz','password':'StrongPass234','confirm_password':'StrongPass234'},follow_redirects=True)
    assert response.status_code==200
    assert client.get('/setup').status_code==302
    client.post('/logout',data={'csrf_token':csrf(client)})
    response=client.post('/login',data={'csrf_token':csrf(client),'email':'admin@demo.kz','password':'StrongPass234'},follow_redirects=True)
    assert response.status_code==200

def test_event_capacity(client):
    client.get('/setup')
    client.post('/setup',data={'csrf_token':csrf(client),'name':'A','email':'a@demo.kz','password':'StrongPass234','confirm_password':'StrongPass234'})
    client.post('/admin/events',data={'csrf_token':csrf(client),'title':'Test Event','description':'Community cleanup','category':'Eco','city':'Almaty','venue':'Park','starts_at':'2099-01-20T10:00','capacity':'1','hours':'2'})
    client.post('/logout',data={'csrf_token':csrf(client)})
    client.post('/register',data={'csrf_token':csrf(client),'name':'V1','email':'v1@demo.kz','password':'StrongPass234','confirm_password':'StrongPass234'})
    client.post('/events/1/join',data={'csrf_token':csrf(client)})
    assert b'1 / 1' in client.get('/events/1').data
    client.post('/logout',data={'csrf_token':csrf(client)})
    client.post('/register',data={'csrf_token':csrf(client),'name':'V2','email':'v2@demo.kz','password':'StrongPass234','confirm_password':'StrongPass234'})
    client.post('/events/1/join',data={'csrf_token':csrf(client)})
    assert b'0 / 1' in client.get('/events/1').data

def test_setup_is_private_and_one_time(client):
    assert client.get('/').status_code == 200
    assert client.get('/setup', environ_overrides={'REMOTE_ADDR':'192.0.2.15'}).status_code == 403
    client.post('/setup', data={'csrf_token':csrf(client), 'name':'Admin', 'email':'boss@demo.kz', 'password':'StrongPass234', 'confirm_password':'StrongPass234'})
    assert client.get('/setup').status_code == 302
    assert client.get('/').status_code == 200
