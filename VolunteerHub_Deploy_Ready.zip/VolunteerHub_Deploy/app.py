"""VolunteerHub 3.0 — local Flask educational portal, Python 3.10+."""
import io
import os
import secrets
import sqlite3
from datetime import datetime, date
from functools import wraps
from pathlib import Path
from flask import Flask, abort, flash, g, redirect, render_template, request, send_file, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT = Path(__file__).resolve().parent
DATABASE = Path(os.getenv('VOLUNTEER_DB', str(ROOT / 'volunteerhub.sqlite3')))
KEY_FILE = ROOT / '.local_secret'
if os.getenv('SECRET_KEY'):
    SECRET = os.environ['SECRET_KEY']
elif KEY_FILE.exists():
    SECRET = KEY_FILE.read_text(encoding='utf-8').strip()
else:
    SECRET = secrets.token_hex(32)
    KEY_FILE.write_text(SECRET, encoding='utf-8')
app = Flask(__name__)
app.config.update(SECRET_KEY=SECRET, SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax', SESSION_COOKIE_SECURE=os.getenv('PUBLIC_HTTPS') == '1')

SCHEMA = '''
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
 city TEXT NOT NULL DEFAULT '', bio TEXT NOT NULL DEFAULT '', role TEXT NOT NULL DEFAULT 'volunteer',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS events (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT NOT NULL,
 category TEXT NOT NULL, city TEXT NOT NULL, venue TEXT NOT NULL, starts_at TEXT NOT NULL,
 hours INTEGER NOT NULL CHECK (hours BETWEEN 1 AND 24), capacity INTEGER NOT NULL CHECK(capacity > 0),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS registrations (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id),
 event_id INTEGER NOT NULL REFERENCES events(id), status TEXT NOT NULL DEFAULT 'registered'
 CHECK(status IN ('registered','attended')),
 registered_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(user_id,event_id)
);
CREATE INDEX IF NOT EXISTS reg_event_idx ON registrations(event_id);
'''

def db():
    if 'db' not in g:
        DATABASE.parent.mkdir(parents=True,exist_ok=True)
        g.db=sqlite3.connect(str(DATABASE),timeout=15,isolation_level=None)
        g.db.row_factory=sqlite3.Row
        g.db.execute('PRAGMA foreign_keys=ON')
        g.db.execute('PRAGMA busy_timeout=15000')
    return g.db

@app.teardown_appcontext
def close_db(error):
    conn=g.pop('db',None)
    if conn: conn.close()

def init_db():
    db().executescript(SCHEMA)

def current_user():
    uid=session.get('uid')
    return db().execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone() if uid else None

def admin_exists():
    return bool(db().execute("SELECT 1 FROM users WHERE role='admin' LIMIT 1").fetchone())

@app.before_request
def before():
    init_db()
    if request.method=='POST':
        if not secrets.compare_digest(str(session.get('csrf','')),str(request.form.get('csrf_token',''))):
            abort(400,'Қауіпсіздік токені сәйкес келмейді. Бетті жаңартыңыз.')
    # The public homepage remains open even before initial administrator setup.
    # First administrator can be created separately at /setup on localhost.

@app.context_processor
def inject():
    if 'csrf' not in session: session['csrf']=secrets.token_urlsafe(32)
    return {'me': current_user(), 'csrf':session['csrf'], 'today':date.today().isoformat()}

def login_required(fn):
    @wraps(fn)
    def inner(*args,**kwargs):
        if not current_user():
            flash('Алдымен аккаунтыңызға кіріңіз.','warning')
            return redirect(url_for('login'))
        return fn(*args,**kwargs)
    return inner

def admin_required(fn):
    @wraps(fn)
    def inner(*args,**kwargs):
        user=current_user()
        if not user: return redirect(url_for('login'))
        if user['role']!='admin': abort(403)
        return fn(*args,**kwargs)
    return inner

def valid_password(value): return len(value)>=8 and len(value)<=128

@app.route('/setup',methods=['GET','POST'])
def setup():
    if admin_exists(): return redirect(url_for('home'))
    # Remote bootstrap requires an independent secret provided in hosting settings.
    is_local = request.remote_addr in ('127.0.0.1', '::1')
    setup_token = os.getenv('SETUP_TOKEN', '')
    if not is_local and not setup_token:
        abort(403, 'Әкімшіні жасау үшін хостингте SETUP_TOKEN орнатыңыз.')
    if request.method=='POST':
        if not is_local and not secrets.compare_digest(setup_token, request.form.get('setup_token', '')):
            abort(403, 'Баптау коды дұрыс емес.')
        name=request.form.get('name','').strip()
        email=request.form.get('email','').strip().lower()
        password=request.form.get('password','')
        if not name or len(name)>90 or '@' not in email or len(email)>150 or not valid_password(password):
            flash('Аты-жөніңізді, email және кемінде 8 таңбалы құпиясөз енгізіңіз.','error')
        elif password!=request.form.get('confirm_password',''):
            flash('Құпиясөздер сәйкес емес.','error')
        else:
            try:
                # Enforce only one bootstrap administrator atomically.
                db().execute('BEGIN IMMEDIATE')
                if admin_exists():
                    db().execute('ROLLBACK')
                    return redirect(url_for('login'))
                cur=db().execute('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)',
                    (name,email,generate_password_hash(password),'admin'))
                db().execute('COMMIT')
                session.clear();session['uid']=cur.lastrowid
                flash('Әкімші аккаунты құрылды! Қош келдіңіз.','success')
                return redirect(url_for('admin'))
            except sqlite3.IntegrityError:
                db().execute('ROLLBACK')
                flash('Бұл email бұрын тіркелген.','error')
    return render_template('auth.html', mode='setup', remote_setup=not is_local)

@app.get('/')
def home():
    rows=db().execute('''SELECT e.*, (SELECT COUNT(*) FROM registrations r WHERE r.event_id=e.id) taken
                          FROM events e ORDER BY e.starts_at ASC, e.id DESC''').fetchall()
    category=request.args.get('category','').strip()
    query=request.args.get('q','').strip().lower()
    events=[x for x in rows if (not category or x['category']==category) and
        (not query or query in (x['title']+' '+x['city']+' '+x['description']).lower())]
    return render_template('index.html',events=events,categories=sorted({x['category'] for x in rows}),q=request.args.get('q',''),category=category)

@app.route('/register',methods=['GET','POST'])
def register():
    if current_user(): return redirect(url_for('dashboard'))
    if request.method=='POST':
        name=request.form.get('name','').strip(); email=request.form.get('email','').strip().lower()
        password=request.form.get('password','')
        if not name or len(name)>90 or '@' not in email or len(email)>150 or not valid_password(password):
            flash('Аты-жөніңізді, email және кемінде 8 таңбалы құпиясөз енгізіңіз.','error')
        elif password!=request.form.get('confirm_password',''):
            flash('Құпиясөздер сәйкес емес.','error')
        else:
            try:
                cur=db().execute('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)',
                    (name,email,generate_password_hash(password)))
                session.clear();session['uid']=cur.lastrowid
                flash('Профиліңіз дайын!','success')
                return redirect(url_for('dashboard'))
            except sqlite3.IntegrityError:
                flash('Бұл email тіркелген. Кіру бетін қолданыңыз.','error')
    return render_template('auth.html',mode='register')

@app.route('/login',methods=['GET','POST'])
def login():
    if current_user(): return redirect(url_for('dashboard'))
    if request.method=='POST':
        email=request.form.get('email','').strip().lower()
        user=db().execute('SELECT * FROM users WHERE email=?',(email,)).fetchone()
        if user and check_password_hash(user['password_hash'],request.form.get('password','')):
            session.clear();session['uid']=user['id']
            flash('Қайта келгеніңізге қуаныштымыз!','success')
            return redirect(url_for('admin' if user['role']=='admin' else 'dashboard'))
        flash('Email немесе құпиясөз қате.','error')
    return render_template('auth.html',mode='login')

@app.post('/logout')
def logout():
    session.clear();flash('Аккаунттан шықтыңыз.','success')
    return redirect(url_for('home'))

@app.get('/events/<int:event_id>')
def event_detail(event_id):
    event=db().execute('''SELECT e.*, (SELECT COUNT(*) FROM registrations r WHERE r.event_id=e.id) taken FROM events e WHERE e.id=?''',(event_id,)).fetchone()
    if not event: abort(404)
    user=current_user()
    registration=db().execute('SELECT * FROM registrations WHERE user_id=? AND event_id=?',
        (user['id'],event_id)).fetchone() if user else None
    return render_template('event.html',event=event,registration=registration)

@app.post('/events/<int:event_id>/join')
@login_required
def join(event_id):
    try:
        db().execute('BEGIN IMMEDIATE')
        event=db().execute('SELECT * FROM events WHERE id=?',(event_id,)).fetchone()
        if not event: db().execute('ROLLBACK');abort(404)
        taken=db().execute('SELECT COUNT(*) FROM registrations WHERE event_id=?',(event_id,)).fetchone()[0]
        exists=db().execute('SELECT 1 FROM registrations WHERE user_id=? AND event_id=?',
            (current_user()['id'],event_id)).fetchone()
        if exists: flash('Сіз бұрын тіркелгенсіз.','warning')
        elif taken>=event['capacity']: flash('Өкінішке қарай, бос орын қалған жоқ.','error')
        elif event['starts_at'][:10]<date.today().isoformat():flash('Өткен іс-шараға тіркелуге болмайды.','error')
        else:
            db().execute('INSERT INTO registrations(user_id,event_id) VALUES (?,?)',(current_user()['id'],event_id))
            flash('Сәтті тіркелдіңіз!','success')
        db().execute('COMMIT')
    except Exception:
        if db().in_transaction: db().execute('ROLLBACK')
        raise
    return redirect(url_for('event_detail',event_id=event_id))

@app.post('/events/<int:event_id>/leave')
@login_required
def leave(event_id):
    reg=db().execute('SELECT * FROM registrations WHERE event_id=? AND user_id=?',(event_id,current_user()['id'])).fetchone()
    if reg and reg['status']=='registered':
        db().execute('DELETE FROM registrations WHERE id=?',(reg['id'],))
        flash('Тіркелуден бас тарттыңыз.','success')
    else: flash('Расталған қатысуды жою мүмкін емес.','warning')
    return redirect(url_for('event_detail',event_id=event_id))

def user_stats(uid):
    info=db().execute('''SELECT COUNT(*) total,
      COALESCE(SUM(CASE WHEN r.status='attended' THEN e.hours ELSE 0 END),0) hours,
      COALESCE(SUM(CASE WHEN r.status='attended' THEN 1 ELSE 0 END),0) completed
      FROM registrations r JOIN events e ON e.id=r.event_id WHERE r.user_id=?''',(uid,)).fetchone()
    return dict(info)

@app.get('/dashboard')
@login_required
def dashboard():
    user=current_user()
    registrations=db().execute('''SELECT r.*,e.title,e.category,e.city,e.starts_at,e.hours,e.venue,
       e.id event_id FROM registrations r JOIN events e ON e.id=r.event_id
       WHERE r.user_id=? ORDER BY e.starts_at DESC''',(user['id'],)).fetchall()
    return render_template('dashboard.html',registrations=registrations,stats=user_stats(user['id']))

@app.route('/profile',methods=['GET','POST'])
@login_required
def profile():
    user=current_user()
    if request.method=='POST':
        name=request.form.get('name','').strip();city=request.form.get('city','').strip()
        bio=request.form.get('bio','').strip()
        if not name or len(name)>90 or len(city)>100 or len(bio)>500:flash('Енгізілген мәлімет тым ұзын немесе бос.','error')
        else:
            db().execute('UPDATE users SET name=?,city=?,bio=? WHERE id=?',(name,city,bio,user['id']))
            flash('Профиль сақталды.','success');return redirect(url_for('profile'))
    return render_template('profile.html',stats=user_stats(user['id']))

@app.route('/change-password',methods=['POST'])
@login_required
def change_password():
    user=current_user(); old=request.form.get('old_password',''); new=request.form.get('new_password','')
    if not check_password_hash(user['password_hash'],old):flash('Ескі құпиясөз қате.','error')
    elif not valid_password(new):flash('Жаңа құпиясөз кемінде 8 таңба болуы керек.','error')
    elif new!=request.form.get('confirm_password',''):flash('Жаңа құпиясөздер сәйкес емес.','error')
    else:
        db().execute('UPDATE users SET password_hash=? WHERE id=?',(generate_password_hash(new),user['id']))
        flash('Құпиясөз жаңартылды.','success')
    return redirect(url_for('profile'))

@app.get('/admin')
@admin_required
def admin():
    events=db().execute('''SELECT e.*,COUNT(r.id) taken,
       SUM(CASE WHEN r.status='attended' THEN 1 ELSE 0 END) attended
       FROM events e LEFT JOIN registrations r ON e.id=r.event_id GROUP BY e.id ORDER BY e.starts_at DESC''').fetchall()
    users=db().execute("SELECT COUNT(*) FROM users WHERE role='volunteer'").fetchone()[0]
    regs=db().execute('SELECT COUNT(*) FROM registrations').fetchone()[0]
    completed=db().execute("SELECT COUNT(*) FROM registrations WHERE status='attended'").fetchone()[0]
    return render_template('admin.html',events=events,users=users,regs=regs,completed=completed)

@app.post('/admin/events')
@admin_required
def create_event():
    try:
        title=request.form.get('title','').strip();description=request.form.get('description','').strip()
        category=request.form.get('category','').strip();city=request.form.get('city','').strip()
        venue=request.form.get('venue','').strip();starts_at=request.form.get('starts_at','').strip()
        cap=int(request.form.get('capacity','0'));hours=int(request.form.get('hours','0'))
        datetime.strptime(starts_at,'%Y-%m-%dT%H:%M')
        if not (title and description and category and city and venue and 1<=cap<=100000 and 1<=hours<=24):raise ValueError()
        if max(map(len,[title,category,city,venue]))>120 or len(description)>3000:raise ValueError()
        db().execute('''INSERT INTO events(title,description,category,city,venue,starts_at,capacity,hours)
          VALUES(?,?,?,?,?,?,?,?)''',(title,description,category,city,venue,starts_at,cap,hours))
        flash('Іс-шара жарияланды!','success')
    except (ValueError,TypeError):flash('Өрістерді дұрыс толтырыңыз.','error')
    return redirect(url_for('admin'))

@app.get('/admin/events/<int:event_id>')
@admin_required
def admin_event(event_id):
    event=db().execute('SELECT * FROM events WHERE id=?',(event_id,)).fetchone()
    if not event:abort(404)
    regs=db().execute('''SELECT r.*,u.name,u.email,u.city FROM registrations r
      JOIN users u ON u.id=r.user_id WHERE r.event_id=? ORDER BY r.registered_at DESC''',(event_id,)).fetchall()
    return render_template('admin_event.html',event=event,regs=regs)

@app.post('/admin/registrations/<int:reg_id>/confirm')
@admin_required
def confirm(reg_id):
    row=db().execute('SELECT * FROM registrations WHERE id=?',(reg_id,)).fetchone()
    if not row:abort(404)
    db().execute("UPDATE registrations SET status='attended' WHERE id=?",(reg_id,))
    flash('Қатысу расталды. Сертификат қолжетімді.','success')
    return redirect(url_for('admin_event',event_id=row['event_id']))

@app.post('/admin/registrations/<int:reg_id>/undo')
@admin_required
def undo(reg_id):
    row=db().execute('SELECT * FROM registrations WHERE id=?',(reg_id,)).fetchone()
    if not row:abort(404)
    db().execute("UPDATE registrations SET status='registered' WHERE id=?",(reg_id,))
    flash('Растау қайтарылды.','success')
    return redirect(url_for('admin_event',event_id=row['event_id']))

@app.get('/certificate/<int:reg_id>')
@login_required
def certificate(reg_id):
    reg=db().execute('''SELECT r.*,u.name,e.title,e.starts_at,e.hours,e.city
       FROM registrations r JOIN users u ON r.user_id=u.id JOIN events e ON r.event_id=e.id
       WHERE r.id=?''',(reg_id,)).fetchone()
    if not reg:abort(404)
    user=current_user()
    if reg['user_id']!=user['id'] and user['role']!='admin':abort(403)
    if reg['status']!='attended':abort(403,'Қатысу әлі расталмаған.')
    font_paths=['C:/Windows/Fonts/arial.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf']
    font=next((p for p in font_paths if Path(p).exists()),None)
    if not font:abort(500,'Кирилл қарпін табу мүмкін болмады. README нұсқаулығын қараңыз.')
    try:pdfmetrics.getFont('VolunteerFont')
    except KeyError:pdfmetrics.registerFont(TTFont('VolunteerFont',font))
    buffer=io.BytesIO();c=canvas.Canvas(buffer,pagesize=A4)
    width,height=A4
    c.setFillColorRGB(0.96,0.97,1);c.rect(0,0,width,height,fill=1,stroke=0)
    c.setStrokeColorRGB(.20,.36,.95);c.setLineWidth(5);c.rect(26,26,width-52,height-52)
    c.setFillColorRGB(.11,.18,.36);c.setFont('VolunteerFont',18);c.drawCentredString(width/2,height-145,'VOLUNTEERHUB')
    c.setFont('VolunteerFont',30);c.drawCentredString(width/2,height-215,'СЕРТИФИКАТ')
    c.setFont('VolunteerFont',14);c.drawCentredString(width/2,height-275,'Еріктілік іс-шарасына қатысқаны үшін')
    c.setFillColorRGB(.15,.35,.87)
    def fit(text,maxwidth,base):
        size=base
        while pdfmetrics.stringWidth(text,'VolunteerFont',size)>maxwidth and size>9:size-=1
        return size
    c.setFont('VolunteerFont',fit(reg['name'],width-100,24));c.drawCentredString(width/2,height-332,reg['name'])
    c.setFillColorRGB(.11,.18,.36)
    c.setFont('VolunteerFont',fit(reg['title'],width-90,17));c.drawCentredString(width/2,height-405,reg['title'])
    c.setFont('VolunteerFont',12);c.drawCentredString(width/2,height-448,f"{reg['city']} · {reg['starts_at'][:10]} · {reg['hours']} сағат")
    c.setFont('VolunteerFont',10);c.drawCentredString(width/2,110,f"Тіркеу № VH-{reg['id']:06d} · Қатысу расталған")
    c.showPage();c.save();buffer.seek(0)
    return send_file(buffer,mimetype='application/pdf',as_attachment=True,download_name=f"VolunteerHub_certificate_{reg_id}.pdf")

@app.errorhandler(403)
@app.errorhandler(404)
def error_page(err):return render_template('error.html',message=str(err)),err.code

if __name__=='__main__':
    with app.app_context():init_db()
    app.run(host='127.0.0.1',port=int(os.getenv('PORT','5000')),debug=False)
